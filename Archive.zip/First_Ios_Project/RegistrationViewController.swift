//
//  RegistrationViewController.swift
//  First_Ios_Project
//
//  Created by Avik Saadhukhan on 23/11/21.
//

import UIKit

class RegistrationViewController: UIViewController {

    @IBAction func Submit(_ sender: UIButton) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()

    }
}
